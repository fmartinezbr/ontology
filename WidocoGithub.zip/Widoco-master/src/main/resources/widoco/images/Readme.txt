icons made by Freepik and Chris Veigt from www.flaticon.com 

Sizes 26x26